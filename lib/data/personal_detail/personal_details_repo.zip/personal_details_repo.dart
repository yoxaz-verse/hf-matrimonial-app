import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../utils/config.dart';
import '../api_client/api_client.dart';

//create and update api are same
abstract class PersonalDetailsRepository {
  Future<Map<String, dynamic>?> createDetails({
    required String authtoken,
    required String name,
    required String about,
    required String age,
    required String DOB,
    required String height,
    required String weight,
    // required String BodyType,
    // required String complexion,
    required String MartialStatus,
    required String PhysicalStatus,
    required String Gender,
    required String Address,
  });

  Future<Map<String, dynamic>?> updateDetails({
    required String authtoken,
    required String id,
    required String name,
    required String about,
    required String age,
    required String DOB,
    required String height,
    required String weight,
    // required String BodyType,
    // required String complexion,
    required String MartialStatus,
    required String PhysicalStatus,
    required String Gender,
    required String Address,
  });

  Future<Map<String, dynamic>?> getdetailsbyid({
    required String authtoken,
    String id,
    String accountId,
    String account,
    String BodyType,
    String complexion,
    String MartialStatus,
    String PhysicalStatus,
    String Gender,
    String pageNo,
    String limit,
  });

  Future<Map<String, dynamic>?> getalldetails({
    required String authtoken,
    required String id,
  });
}

class PersonalDetailsRepositoryV1 implements PersonalDetailsRepository {
  PersonalDetailsRepositoryV1(this.api);

  final ApiClient api;

  @override
  Future<Map<String, dynamic>?> createDetails({
    required String authtoken,
    required String name,
    required String about,
    required String age,
    required String DOB,
    required String height,
    required String weight,
    // required String BodyType,
    // required String complexion,
    required String MartialStatus,
    required String PhysicalStatus,
    required String Gender,
    required String Address,
  }) {
    final body = {
      "name": name,
      "about": about,
      "age": age,
      "DOB": DOB,
      "height": height,
      "weight": weight,
      // "BodyType": BodyType,
      // "complexion": complexion,
      "MartialStatus": MartialStatus,
      "PhysicalStatus": PhysicalStatus,
      "Gender": Gender,
      "Address": Address,
    };

    return api.postData(
      uri: Uri.parse(ApiConfig.personalDetailURl),
      body: body,
      headers: api.createHeaders(
        authtoken: "",
      ),
      builder: (data) {
        Map<String, dynamic> jsonMap = json.decode(data);

        if (jsonMap["status"] == true) {
          debugPrint("adddetails data1 is =- $jsonMap");

          return jsonMap;
        } else {
          throw Exception('Failed..');
        }
      },
    );
  }

  @override
  Future<Map<String, dynamic>?> updateDetails({
    required String authtoken,
    required String id,
    required String name,
    required String about,
    required String age,
    required String DOB,
    required String height,
    required String weight,
    // required String BodyType,
    // required String complexion,
    required String MartialStatus,
    required String PhysicalStatus,
    required String Gender,
    required String Address,
  }) {
    final body = {
      "id": id,
      // "user_id": user_id,
      "name": name,
      "about": about,
      "age": age,
      "DOB": DOB,
      "height": height,
      "weight": weight,
      // "BodyType": BodyType,
      // "complexion": complexion,
      "MartialStatus": MartialStatus,
      "PhysicalStatus": PhysicalStatus,
      "Gender": Gender,
      "Address": Address,
    };

    return api.postData(
      uri: Uri.parse("${ApiConfig.personalDetailURl}$id"),
      body: body,
      headers: api.createHeaders(
        authtoken: "",
      ),
      builder: (data) {
        Map<String, dynamic> jsonMap = json.decode(data);

        if (jsonMap["status"] == true) {
          debugPrint("adddetails data1 is =- $jsonMap");

          return jsonMap;
        } else {
          throw Exception('Failed..');
        }
      },
    );
  }

  // @override
  // Future<Map<String, dynamic>?> getdetails({
  //   required String authtoken,
  //   required String id,
  // }) {
  //   return api.getData(
  //     uri: Uri.parse("${ApiConfig.personalDetailURl}$id"),
  //     headers: api.createHeaders(authtoken: authtoken),
  //     builder: (data) {
  //       Map<String, dynamic> jsonMap = {"data": json.decode(data)};
  //
  //       if (jsonMap['data'] != []) {
  //         return jsonMap;
  //       } else {
  //         throw Exception('Failed..');
  //       }
  //     },
  //   );
  // }

  @override
  Future<Map<String, dynamic>?> getalldetails(
      {required String authtoken, required String id}) {
    return api.getData(
      uri: Uri.parse("${ApiConfig.personalDetailURl}$id"),
      headers: api.createHeaders(authtoken: authtoken),
      builder: (data) {
        Map<String, dynamic> jsonMap = {"data": json.decode(data)};

        if (jsonMap['data'] != []) {
          return jsonMap;
        } else {
          throw Exception('Failed..');
        }
      },
    );
  }

  @override
  Future<Map<String, dynamic>?> getdetailsbyid({
    required String authtoken,
    String id = "",
    String accountId = "",
    String account = "",
    String BodyType = "",
    String complexion = "",
    String MartialStatus = "",
    String PhysicalStatus = "",
    String Gender = "",
    String pageNo = "",
    String limit = "",
  }) {
    String url = ApiConfig.personalDetailURl;
    if (id != '') {
      url = "$url?id=$id";
    }
    if (accountId != '') {
      url = "$url?accountId=$accountId";
    }
    if (account != '') {
      url = "$url?accountId=$account";
    }
    if (BodyType != '') {
      url = "$url?employedIn=$BodyType";
    }
    if (complexion != '') {
      url = "$url?occupation=$complexion";
    }
    if (MartialStatus != '') {
      url = "$url?highestEducation=$MartialStatus";
    }
    if (PhysicalStatus != '') {
      url = "$url?religion=$PhysicalStatus";
    }
    if (Gender != '') {
      url = "$url?workLocation=$Gender";
    }
    if (pageNo != '') {
      url = "$url?pageNo=$pageNo";
    }
    if (limit != '') {
      url = "$url?limit=$limit";
    }

    return api.getData(
      uri: Uri.parse(url),
      headers: api.createHeaders(authtoken: authtoken),
      builder: (data) {
        Map<String, dynamic> jsonMap = json.decode(data);
        if (jsonMap["id"] != null) {
          return jsonMap;
        } else {
          throw Exception('Failed..');
        }
      },
    );
  }
}

final personalDetailsRepositoryProvider =
    Provider<PersonalDetailsRepository>((ref) => PersonalDetailsRepositoryV1(
          ApiClient(),
        ));
